let user:(string| Array<string>) = "nithya";
alert(user);