var user = "nithya";
alert(user);
