"use strict";
// let addPower = function(pow:number){
//     return function(targetClass:any){
//             return class{
//                 title =  new targetClass().title;
//                 power  = pow
//             }
//     }
// }
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// @addPower(6) 
// class Commonman{
//     title = "Nithya"
// };
// let cm = new Commonman();
// console.log(cm.title,cm.power);
//Instead
var addPower = function (config) {
    return function (targetClass) {
        return /** @class */ (function () {
            function class_1() {
                this.title = new targetClass().title;
                this.power = config.power;
                this.selector = config.selector;
                this.template = "\n            <h1> Hello Everyone </h1>\n            ";
            }
            return class_1;
        }());
    };
};
var Commonman = /** @class */ (function () {
    function Commonman() {
        this.title = "Nithya";
    }
    Commonman = __decorate([
        addPower({
            selector: "nithya",
            power: 7,
        })
    ], Commonman);
    return Commonman;
}());
