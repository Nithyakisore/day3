var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
import { Person } from "./Person";
var Hero = /** @class */ (function (_super) {
    __extends(Hero, _super);
    function Hero(title, fname, lname, pow) {
        var _this = _super.call(this, pow) || this;
        _this.title = title;
        _this.fname = fname;
        _this.lname = lname;
        _this._secret = "Secret Mission";
        return _this;
    }
    Hero.prototype.fullname = function () {
        return this.fname + " " + this.lname;
    };
    Hero.prototype.showpower = function () {
        return this.pow;
    };
    Object.defineProperty(Hero.prototype, "secret", {
        get: function () {
            return this._secret;
        },
        set: function (newvalue) {
            this._secret = newvalue;
        },
        enumerable: true,
        configurable: true
    });
    return Hero;
}(Person));
export { Hero };
;
