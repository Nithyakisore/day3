import{Person} from "./Person";

interface Ihero{
    title:string;
    fname:string;
    lname:string;
    fullname():string;
    showpower():number;
}
export class Hero extends Person implements Ihero{

    //alternative way 
    // public title :string;
    //     public fname :string;
    //     public lname :string;
    //     private _secret :string;
    // constructor(title:string,fname:string,lname:string,pow:number){

    //     super(pow);
    //     this.title = title;
    //     this.fname = fname;
    //     this.lname = lname;
    //     this._secret = "top_secret";
    // }
    
  
    private _secret :string;
    constructor(public title :string,
        public fname :string, 
           public lname :string,
            pow:number){
            super(pow);
            this._secret = "Secret Mission";
    }

    fullname():string{
        return this.fname+" "+ this.lname;
    }

    showpower():number{
        return this.pow;
    }

    get secret():string{
            return this._secret
    }
    set secret(newvalue:string){
        this._secret = newvalue;
    }
};
