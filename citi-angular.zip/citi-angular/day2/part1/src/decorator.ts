// let addPower = function(pow:number){
//     return function(targetClass:any){
//             return class{
//                 title =  new targetClass().title;
//                 power  = pow
//             }
//     }
// }


// @addPower(6) 
// class Commonman{
//     title = "Nithya"
// };

// let cm = new Commonman();
// console.log(cm.title,cm.power);
//Instead


let addPower = function(config:any){
    return function(targetClass:any){
        return class{
            title = new targetClass().title;
            power = config.power;
            selector = config.selector;
            template = `
            <h1> Hello Everyone </h1>
            `
        }
    }
}


@addPower({

    selector : "nithya",
    power : 7,
    
})
class Commonman{
    title = "Nithya";
}