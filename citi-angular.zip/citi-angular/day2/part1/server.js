let express = require("express");
let app = express();
app.use(express.static(__dirname));
app.get("/",function(request,response){
    // response.send("welcome to tik tik");
    response.sendFile(__dirname+"/step-12-class-interface.html")
});
app.listen(9090);
console.log("server is now live on localhost :9090");