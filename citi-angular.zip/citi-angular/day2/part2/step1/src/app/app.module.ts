import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { CitiComponent } from './citi.component';



@NgModule({
  declarations: [
    AppComponent ,CitiComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent
  ]
})
export class AppModule { }
