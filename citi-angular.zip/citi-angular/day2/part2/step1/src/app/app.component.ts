import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  // template: `<h1>Hello lol</h1>`
  // template : `<h1> {{ title }}</h1> <hr><app-citi></app-citi>`
  template : `
  <div class =  "box">
  <h1> {{ title }}</h1> 

  <h1 [innerHTML]="title" > </h1> 
  <h1 bind-innerHTML="title" > </h1> 
  <hr>
  <button (click) = "clickhandler()">click me </button>
   
    <input (keydown.space)="keyHandler()" type ="text">
    <br>
    <img src = "assets/images/superman.jpg"  alt ="superman">
    <img src = "{{photo}}" alt ="spiderman">
    <img bind-src = "photo"  alt ="spiderman">
    <img [src] = "photo"  alt ="spiderman">
    <hr>
    <input #ti type = "text">
    <button (click) = "checkValuehandler(ti.value)"> check value </button>
  <app-citi></app-citi>
  </div>`,
  styles:[
    `.box{
      border : 2px solid black;
      background-color : silver;
    },
    hr{
      border : #333;
    }
    `
  ]
})

export class AppComponent {
  title = 'Hello World';
  photo = 'assets/images/superman.jpg'
  clickhandler(){
    alert("HELLLlloooo")
  }

  keyHandler(){
    console.log("inside");
  }
  checkValuehandler(message:string){
    alert(message);
  }
}
