import { Component } from '@angular/core'

@Component({
    selector : 'app-citi',
    template : `<h1>Helo from Citi Componenet  </h1>`
})


export class CitiComponent{
    
}