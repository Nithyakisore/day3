import { Directive, OnInit, ElementRef } from '@angular/core';

@Directive({
    selector : 'citibank'
})

export class  CitiDirective implements OnInit{
 
    constructor(private elm:ElementRef){

    }
ngOnInit(){
this.elm.nativeElement.innerHTML = "Changed by Citi bank <br>"
}
}