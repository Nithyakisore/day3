import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { GenPipe } from './gen.pipe';
import { CitiDirective } from './citi.directive';

@NgModule({
  declarations: [
    AppComponent,GenPipe,CitiDirective
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
