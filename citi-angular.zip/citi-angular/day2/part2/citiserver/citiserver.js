let express = require("express");
let cors = require("cors");
let data = require("./herodata.json")
let app = express();

app.use(cors());

app.get("/data",function(req,res){
    res.send(data);
})

app.listen(2020);
console.log("server is now live on localhost:2020/data");