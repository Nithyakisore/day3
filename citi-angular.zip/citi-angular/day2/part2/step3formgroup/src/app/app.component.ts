import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `<app-template-form> </app-template-form>`
  })
export class AppComponent {
  title = 'step3forms';
}
