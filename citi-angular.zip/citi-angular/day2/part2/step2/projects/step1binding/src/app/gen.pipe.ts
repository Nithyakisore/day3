import { Pipe, PipeTransform } from '@angular/core';


@Pipe({

    name:'citi'
})

export class GenPipe implements PipeTransform{
constructor(){}
    transform(){


}
}