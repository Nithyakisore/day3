import { Component } from '@angular/core';
import { HeroService } from './hero.service';

@Component({

    selector:'app-main',
    template: `<h1> Hello from Citi Application </h1>
    <app-header [data]="herolist?.h1"></app-header>
    <app-grid  [data]="herolist?.h1"></app-grid>
    `

})



export class MainComponent{
    herolist:any;
    constructor(public hero:HeroService){ }
    ngOnInit(){
        this.hero.getHeroes().subscribe((data) => {
             this.herolist = data;
        });
     }

}