export class Person{
    power:number;
    constructor(pow:number){
        this.power = pow;
    }

}