import{Person} from "./Person.js";
export class Hero extends Person{
    constructor(title,fname,lname,pow){

        super(pow)
        this.title = title;
        this.fname = fname;
        this.lname = lname;
        this._secret = "top_secret";
    }

    fullname(){
        return this.fname+" "+ this.lname;
    }

    get secret(){
        return this._secret
    }
    set secret(newvalue){
        this._secret = newvalue;
    }
};
